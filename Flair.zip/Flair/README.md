# Flair

Steps to create a Flair Project.

FOR MAC OS X 

  1. Have node and npm installed and make sure its up to date enough to create a ReactJS Project.

  2. Make sure Python3 is installed using Home Brew on a Mac.

  3. Make sure pipenv is installed by running pip3 install pipenv

  4. Clone this repo and leave it somewhere where it wont be deleted

  5. To create a Flair project, cd into the downloaded folder and run python project-flair.py <Base Path of Project> <Project      Name> <Optional: ReactUIName> <Optional: App File Name>

  Ex. python project-flair.py ~/Documents/PythonProjects React+Flask react-ui Mango

This command will create the project titled React+Flask under the Documents/PythonProjects directory with a React folder titles react-ui and the generated app file after running the build script will be called Mango.app
