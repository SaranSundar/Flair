def long_method():
    # This is just a dummy long method
    # If the method is very long you can separate it
    # into an api file and import it in you bp file
    for i in range(100):
        x = 5
        e = 3
        r = 1
        hello = "bye"
    for i in range(100):
        x = 5
        e = 3
        r = 1
        hello = "bye"
    for i in range(100):
        x = 5
        e = 3
        r = 1
        hello = "bye"
